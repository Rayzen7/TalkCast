const Text2 = () => {
  return (
    <div className="w-full h-auto lg:h-[45vh] flex flex-col justify-center items-center bg-pink py-16 lg:px-0 px-6 lg:py-16">
        <p className="text-[27px] w-full lg:w-[600px] font-poppins lg:text-[38px] text-center">“Learning, Working, and Building.”</p>
    </div>
  )
}

export default Text2