import Router from "./router/Router";

const App = () => {
  return (
    <div>
      <Router/>
    </div>
  )
}

export default App